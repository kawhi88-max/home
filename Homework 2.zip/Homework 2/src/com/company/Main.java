package com.company;

public class Main {

    public static void main(String[] args) {
        System.out.println(ageOfPerson());
        System.out.println(temperature());
    }
    public static int ageOfPerson(){
        return 35 - 20;
    }
    public static int temperature(){
        return 10 + 12;
    }

}
